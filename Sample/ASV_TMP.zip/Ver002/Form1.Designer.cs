namespace HID_PnP_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ToggleLEDs_btn = new System.Windows.Forms.Button();
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.ANxVoltageToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.ToggleLEDToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.PushbuttonStateTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.connect_status_lbl = new System.Windows.Forms.Label();
            this.current_temp_lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.current_vol_lbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.current_SW_lbl = new System.Windows.Forms.Label();
            this.brightness_num = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.logging_lstv = new System.Windows.Forms.ListView();
            this.col_No = new System.Windows.Forms.ColumnHeader();
            this.col_time = new System.Windows.Forms.ColumnHeader();
            this.col_temp = new System.Windows.Forms.ColumnHeader();
            this.col_vol = new System.Windows.Forms.ColumnHeader();
            this.col_SW = new System.Windows.Forms.ColumnHeader();
            this.measure_strart_btn = new System.Windows.Forms.Button();
            this.interval_loging_num = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.save_cvs_btn = new System.Windows.Forms.Button();
            this.data_clear_btn = new System.Windows.Forms.Button();
            this.log_timer = new System.Windows.Forms.Timer(this.components);
            this.measure_stop_btn = new System.Windows.Forms.Button();
            this.disp_select_cmb = new System.Windows.Forms.ComboBox();
            this.disp_change_btn = new System.Windows.Forms.Button();
            this.performanceCounter = new System.Diagnostics.PerformanceCounter();
            ((System.ComponentModel.ISupportInitialize)(this.brightness_num)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.interval_loging_num)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter)).BeginInit();
            this.SuspendLayout();
            // 
            // ToggleLEDs_btn
            // 
            this.ToggleLEDs_btn.Enabled = false;
            this.ToggleLEDs_btn.Location = new System.Drawing.Point(485, 413);
            this.ToggleLEDs_btn.Name = "ToggleLEDs_btn";
            this.ToggleLEDs_btn.Size = new System.Drawing.Size(96, 21);
            this.ToggleLEDs_btn.TabIndex = 24;
            this.ToggleLEDs_btn.Text = "���邳�Z�b�g";
            this.ToggleLEDs_btn.UseVisualStyleBackColor = true;
            this.ToggleLEDs_btn.Click += new System.EventHandler(this.ToggleLEDs_btn_Click);
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // ANxVoltageToolTip
            // 
            this.ANxVoltageToolTip.AutomaticDelay = 20;
            this.ANxVoltageToolTip.AutoPopDelay = 20000;
            this.ANxVoltageToolTip.InitialDelay = 15;
            this.ANxVoltageToolTip.ReshowDelay = 15;
            this.ANxVoltageToolTip.Popup += new System.Windows.Forms.PopupEventHandler(this.ANxVoltageToolTip_Popup);
            // 
            // ToggleLEDToolTip
            // 
            this.ToggleLEDToolTip.AutomaticDelay = 2000;
            this.ToggleLEDToolTip.AutoPopDelay = 20000;
            this.ToggleLEDToolTip.InitialDelay = 15;
            this.ToggleLEDToolTip.ReshowDelay = 15;
            // 
            // PushbuttonStateTooltip
            // 
            this.PushbuttonStateTooltip.AutomaticDelay = 20;
            this.PushbuttonStateTooltip.AutoPopDelay = 20000;
            this.PushbuttonStateTooltip.InitialDelay = 15;
            this.PushbuttonStateTooltip.ReshowDelay = 15;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 2000;
            this.toolTip1.AutoPopDelay = 20000;
            this.toolTip1.InitialDelay = 15;
            this.toolTip1.ReshowDelay = 15;
            // 
            // toolTip2
            // 
            this.toolTip2.AutomaticDelay = 20;
            this.toolTip2.AutoPopDelay = 20000;
            this.toolTip2.InitialDelay = 15;
            this.toolTip2.ReshowDelay = 15;
            // 
            // connect_status_lbl
            // 
            this.connect_status_lbl.AutoSize = true;
            this.connect_status_lbl.Location = new System.Drawing.Point(10, 448);
            this.connect_status_lbl.Name = "connect_status_lbl";
            this.connect_status_lbl.Size = new System.Drawing.Size(41, 12);
            this.connect_status_lbl.TabIndex = 26;
            this.connect_status_lbl.Text = "���ڑ�";
            // 
            // current_temp_lbl
            // 
            this.current_temp_lbl.AutoSize = true;
            this.current_temp_lbl.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.current_temp_lbl.Location = new System.Drawing.Point(482, 15);
            this.current_temp_lbl.Name = "current_temp_lbl";
            this.current_temp_lbl.Size = new System.Drawing.Size(60, 21);
            this.current_temp_lbl.TabIndex = 27;
            this.current_temp_lbl.Text = "label1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(416, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 12);
            this.label1.TabIndex = 28;
            this.label1.Text = "���݂̉��x";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(545, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(17, 12);
            this.label2.TabIndex = 29;
            this.label2.Text = "��";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(407, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 12);
            this.label3.TabIndex = 30;
            this.label3.Text = "�{�����[���̒l";
            // 
            // current_vol_lbl
            // 
            this.current_vol_lbl.AutoSize = true;
            this.current_vol_lbl.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.current_vol_lbl.Location = new System.Drawing.Point(482, 40);
            this.current_vol_lbl.Name = "current_vol_lbl";
            this.current_vol_lbl.Size = new System.Drawing.Size(60, 21);
            this.current_vol_lbl.TabIndex = 31;
            this.current_vol_lbl.Text = "label1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(406, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 12);
            this.label5.TabIndex = 32;
            this.label5.Text = "�X�C�b�`�̏��";
            // 
            // current_SW_lbl
            // 
            this.current_SW_lbl.AutoSize = true;
            this.current_SW_lbl.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.current_SW_lbl.Location = new System.Drawing.Point(482, 66);
            this.current_SW_lbl.Name = "current_SW_lbl";
            this.current_SW_lbl.Size = new System.Drawing.Size(60, 21);
            this.current_SW_lbl.TabIndex = 33;
            this.current_SW_lbl.Text = "label1";
            // 
            // brightness_num
            // 
            this.brightness_num.Location = new System.Drawing.Point(418, 415);
            this.brightness_num.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.brightness_num.Name = "brightness_num";
            this.brightness_num.Size = new System.Drawing.Size(61, 19);
            this.brightness_num.TabIndex = 34;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(439, 400);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 12);
            this.label4.TabIndex = 35;
            this.label4.Text = "�i�� 0 <-  -> 3 �Áj";
            // 
            // logging_lstv
            // 
            this.logging_lstv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_No,
            this.col_time,
            this.col_temp,
            this.col_vol,
            this.col_SW});
            this.logging_lstv.GridLines = true;
            this.logging_lstv.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.logging_lstv.Location = new System.Drawing.Point(12, 3);
            this.logging_lstv.Name = "logging_lstv";
            this.logging_lstv.Size = new System.Drawing.Size(376, 442);
            this.logging_lstv.TabIndex = 36;
            this.logging_lstv.UseCompatibleStateImageBehavior = false;
            this.logging_lstv.View = System.Windows.Forms.View.Details;
            // 
            // col_No
            // 
            this.col_No.Text = "No";
            this.col_No.Width = 40;
            // 
            // col_time
            // 
            this.col_time.Text = "Time";
            this.col_time.Width = 118;
            // 
            // col_temp
            // 
            this.col_temp.Text = "temperature";
            this.col_temp.Width = 74;
            // 
            // col_vol
            // 
            this.col_vol.Text = "volume";
            this.col_vol.Width = 75;
            // 
            // col_SW
            // 
            this.col_SW.Text = "switch";
            // 
            // measure_strart_btn
            // 
            this.measure_strart_btn.Location = new System.Drawing.Point(516, 160);
            this.measure_strart_btn.Name = "measure_strart_btn";
            this.measure_strart_btn.Size = new System.Drawing.Size(75, 23);
            this.measure_strart_btn.TabIndex = 37;
            this.measure_strart_btn.Text = "�J�n";
            this.measure_strart_btn.UseVisualStyleBackColor = true;
            this.measure_strart_btn.Click += new System.EventHandler(this.measure_strart_btn_Click);
            // 
            // interval_loging_num
            // 
            this.interval_loging_num.Location = new System.Drawing.Point(439, 163);
            this.interval_loging_num.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.interval_loging_num.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.interval_loging_num.Name = "interval_loging_num";
            this.interval_loging_num.Size = new System.Drawing.Size(61, 19);
            this.interval_loging_num.TabIndex = 38;
            this.interval_loging_num.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(406, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 12);
            this.label6.TabIndex = 39;
            this.label6.Text = "���M���O�Ԋu(s)";
            // 
            // save_cvs_btn
            // 
            this.save_cvs_btn.Location = new System.Drawing.Point(465, 220);
            this.save_cvs_btn.Name = "save_cvs_btn";
            this.save_cvs_btn.Size = new System.Drawing.Size(75, 23);
            this.save_cvs_btn.TabIndex = 40;
            this.save_cvs_btn.Text = "CSV�ۑ�";
            this.save_cvs_btn.UseVisualStyleBackColor = true;
            this.save_cvs_btn.Click += new System.EventHandler(this.save_cvs_btn_Click);
            // 
            // data_clear_btn
            // 
            this.data_clear_btn.Location = new System.Drawing.Point(465, 249);
            this.data_clear_btn.Name = "data_clear_btn";
            this.data_clear_btn.Size = new System.Drawing.Size(75, 23);
            this.data_clear_btn.TabIndex = 41;
            this.data_clear_btn.Text = "�f�[�^�N���A";
            this.data_clear_btn.UseVisualStyleBackColor = true;
            this.data_clear_btn.Click += new System.EventHandler(this.button3_Click);
            // 
            // log_timer
            // 
            this.log_timer.Interval = 1000;
            this.log_timer.Tick += new System.EventHandler(this.log_timer_tick);
            // 
            // measure_stop_btn
            // 
            this.measure_stop_btn.Enabled = false;
            this.measure_stop_btn.Location = new System.Drawing.Point(516, 189);
            this.measure_stop_btn.Name = "measure_stop_btn";
            this.measure_stop_btn.Size = new System.Drawing.Size(75, 23);
            this.measure_stop_btn.TabIndex = 42;
            this.measure_stop_btn.Text = "��~";
            this.measure_stop_btn.UseVisualStyleBackColor = true;
            this.measure_stop_btn.Click += new System.EventHandler(this.measure_stop_btn_Click);
            // 
            // disp_select_cmb
            // 
            this.disp_select_cmb.FormattingEnabled = true;
            this.disp_select_cmb.Items.AddRange(new object[] {
            "���x",
            "CPU���ח�"});
            this.disp_select_cmb.Location = new System.Drawing.Point(439, 318);
            this.disp_select_cmb.Name = "disp_select_cmb";
            this.disp_select_cmb.Size = new System.Drawing.Size(121, 20);
            this.disp_select_cmb.TabIndex = 43;
            this.disp_select_cmb.SelectedIndexChanged += new System.EventHandler(this.disp_select_cmb_SelectedIndexChanged);
            // 
            // disp_change_btn
            // 
            this.disp_change_btn.Location = new System.Drawing.Point(446, 344);
            this.disp_change_btn.Name = "disp_change_btn";
            this.disp_change_btn.Size = new System.Drawing.Size(96, 21);
            this.disp_change_btn.TabIndex = 44;
            this.disp_change_btn.Text = "�\����ύX";
            this.disp_change_btn.UseVisualStyleBackColor = true;
            this.disp_change_btn.Click += new System.EventHandler(this.disp_change_btn_Click);
            // 
            // performanceCounter
            // 
            this.performanceCounter.CategoryName = "Processor";
            this.performanceCounter.CounterName = "% Processor Time";
            this.performanceCounter.InstanceName = "_Total";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 469);
            this.Controls.Add(this.disp_change_btn);
            this.Controls.Add(this.disp_select_cmb);
            this.Controls.Add(this.measure_stop_btn);
            this.Controls.Add(this.data_clear_btn);
            this.Controls.Add(this.save_cvs_btn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.interval_loging_num);
            this.Controls.Add(this.measure_strart_btn);
            this.Controls.Add(this.logging_lstv);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.brightness_num);
            this.Controls.Add(this.current_SW_lbl);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.current_vol_lbl);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.current_temp_lbl);
            this.Controls.Add(this.connect_status_lbl);
            this.Controls.Add(this.ToggleLEDs_btn);
            this.Name = "Form1";
            this.Text = "ASOOVU USB ���x�v���K�[ Ver1.00";
            ((System.ComponentModel.ISupportInitialize)(this.brightness_num)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.interval_loging_num)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.performanceCounter)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ToggleLEDs_btn;
        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.Windows.Forms.ToolTip ANxVoltageToolTip;
        private System.Windows.Forms.ToolTip ToggleLEDToolTip;
        private System.Windows.Forms.ToolTip PushbuttonStateTooltip;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.Label connect_status_lbl;
        private System.Windows.Forms.Label current_temp_lbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label current_vol_lbl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label current_SW_lbl;
        private System.Windows.Forms.NumericUpDown brightness_num;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListView logging_lstv;
        private System.Windows.Forms.Button measure_strart_btn;
        private System.Windows.Forms.NumericUpDown interval_loging_num;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button save_cvs_btn;
        private System.Windows.Forms.Button data_clear_btn;
        private System.Windows.Forms.Timer log_timer;
        private System.Windows.Forms.ColumnHeader col_No;
        private System.Windows.Forms.ColumnHeader col_time;
        private System.Windows.Forms.ColumnHeader col_temp;
        private System.Windows.Forms.ColumnHeader col_vol;
        private System.Windows.Forms.ColumnHeader col_SW;
        private System.Windows.Forms.Button measure_stop_btn;
        private System.Windows.Forms.ComboBox disp_select_cmb;
        private System.Windows.Forms.Button disp_change_btn;
        private System.Diagnostics.PerformanceCounter performanceCounter;
    }
}

